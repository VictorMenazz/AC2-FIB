var searchData=
[
  ['param_5fdisenyo_5fpkg',['param_disenyo_pkg',['../namespaceparam__disenyo__pkg.html',1,'']]]
];
