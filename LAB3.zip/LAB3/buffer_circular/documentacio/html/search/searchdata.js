var indexSectionsWithContent =
{
  0: "abcdeilmnpqrstv",
  1: "abceimpr",
  2: "cr",
  3: "abcimpr",
  4: "pr",
  5: "abcdeilmnpqrstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

