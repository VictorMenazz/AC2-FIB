var searchData=
[
  ['tam_5fcamino',['tam_camino',['../classcte__tipos__buffer__pkg.html#a8a1da23f170363a69878c31274efeba7',1,'cte_tipos_buffer_pkg']]],
  ['tam_5fpuntero',['tam_puntero',['../classcte__tipos__buffer__pkg.html#af1c53beff5186ad76a27d410f0292915',1,'cte_tipos_buffer_pkg']]],
  ['tam_5fsecuencia',['tam_secuencia',['../classcte__tipos__buffer__pkg.html#a204fd996894cab1e0243fe27c7d42c5b',1,'cte_tipos_buffer_pkg']]]
];
